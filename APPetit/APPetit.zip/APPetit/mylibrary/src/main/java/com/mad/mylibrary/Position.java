package com.mad.mylibrary;

public class Position {
    public Double latitude, longitude;

    public Position() {

    }

    public Position(Double latitude, Double longitude) {
        this.latitude = latitude;
        this.longitude = longitude;
    }
}